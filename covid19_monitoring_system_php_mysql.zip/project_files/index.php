<!doctype html>
    <html lang="en">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Dashboard | CRUD APP</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
            <link rel="stylesheet" href="css/index.css" />

            <?php include('common/header.php') ?>

            <br/>

            <div class="container">
                <h1 class="h1">Dashboard Page</h1><br/>
                <div class="row">
                    <div class="col-md-4 col-sm-6 mb-4">
                        <div class="counter blue">
                            <div class="counter-icon">
                                <i class="fa fa-virus-covid"></i>
                            </div>
                            <span class="counter-value" id="encounter">8</span>
                            <h3>COVID-19 ENCOUNTER</h3>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 mb-4">
                        <div class="counter orange">
                            <div class="counter-icon">
                                <i class="fa fa-syringe"></i>
                            </div>
                            <span class="counter-value" id="vaccinated">8</span>
                            <h3>VACCINATED</h3>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 mb-4">
                        <div class="counter yellow">
                            <div class="counter-icon">
                                <i class="fa fa-temperature-full"></i>
                            </div>
                            <span class="counter-value" id="fever">8</span>
                            <h3>FEVER</h3>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 mb-4">
                        <div class="counter green">
                            <div class="counter-icon">
                                <i class="fa fa-person"></i>
                            </div>
                            <span class="counter-value" id="adult">8</span>
                            <h3>ADULT</h3>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 mb-4">
                        <div class="counter pink">
                            <div class="counter-icon">
                                <i class="fa fa-child-reaching"></i>
                            </div>
                            <span class="counter-value" id="minor">8</span>
                            <h3>MINOR</h3>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 mb-4">
                        <div class="counter gray">
                            <div class="counter-icon">
                                <i class="fa fa-flag"></i>
                            </div>
                            <span class="counter-value" id="foreigner">8</span>
                            <h3>FOREIGNER</h3>
                        </div>
                    </div>
                </div>

                <br/>

                <div>
                    <canvas id="myChart"></canvas>
                </div>

                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            </div>

        <br/>


        <?php include('common/footer.php') ?>

        <script src="js/index.js"></script>
    
    </body>
</html>