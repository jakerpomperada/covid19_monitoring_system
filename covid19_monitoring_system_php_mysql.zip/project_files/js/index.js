

// Index load page
window.addEventListener('load', () => {
    getEncounter();
    getVaccinated();
    getFever();
    getAdult();
    getMinor();
    getForeigner();
    getChartData();
})


function getEncounter() {

    fetch('./php/getEncounter.php')
        .then(response => response.json())
        .then(result => {
            document.querySelector('#encounter').innerHTML = result.totalEncounter
        })

}


function getVaccinated() {

    fetch('./php/getVaccinated.php')
        .then(response => response.json())
        .then(result => {
            document.querySelector('#vaccinated').innerHTML = result.totalVaccinated
        })

}


function getFever() {

    fetch('./php/getFever.php')
        .then(response => response.json())
        .then(result => {
            document.querySelector('#fever').innerHTML = result.totalFever
        })

}


function getAdult() {

    fetch('./php/getAdult.php')
        .then(response => response.json())
        .then(result => {
            document.querySelector('#adult').innerHTML = result.totalAdult
        })

}

function getMinor() {

    fetch('./php/getMinor.php')
        .then(response => response.json())
        .then(result => {
            document.querySelector('#minor').innerHTML = result.totalMinor
        })

}

function getForeigner() {

    fetch('./php/getForeigner.php')
        .then(response => response.json())
        .then(result => {
            document.querySelector('#foreigner').innerHTML = result.totalForeigner
        })

}


function getChartData() {
    let xValue = [];
    let yValue = [];
        
    $.ajax({
        url: './php/getChartData.php',
        method: 'POST',
        data: {},
        dataType: 'json',
        success: (response) => {

            $.each(response, (key, value) => {
                xValue.push(key);
                yValue.push(value);
            });

            const data = {
                labels: xValue,
                datasets: [
                    {
                        label: yValue[0][0]['status'],
                        data: [ yValue[0][0]['statusCount'], yValue[1][0]['statusCount'], yValue[2][0]['statusCount'] ],
                        backgroundColor: [
                            'rgba(91,155,213,0.4)',
                            'rgba(255,192,0,0.4)',
                            'rgba(246,181,154,0.4)'
                        ],
                        borderColor: [
                            'rgb(91,155,213)',
                            'rgb(255,192,0)',
                            'rgb(246,181,154)'
                        ],
                        borderWidth: 1
                    },

                    {
                        label: yValue[0][1]['status'],
                        data: [ yValue[0][1]['statusCount'], yValue[1][1]['statusCount'], yValue[2][1]['statusCount'] ],
                        backgroundColor: [
                            'rgba(91,155,213,0.4)',
                            'rgba(255,192,0,0.4)',
                            'rgba(246,181,154,0.4)'
                        ],
                        borderColor: [
                            'rgb(91,155,213)',
                            'rgb(255,192,0)',
                            'rgb(246,181,154)'
                        ],
                        borderWidth: 1
                    }
                ]
            };

            let chartCanvas = new Chart(
                document.getElementById('myChart'), {
                    type: 'bar',
                    data: data,
                    options: {
                        legend: {
                            display: 'false'
                        },
                        layout: {
                            padding: {
                                top: 30
                            }
                        }
                    }
                }
            );
        }
    });     
}