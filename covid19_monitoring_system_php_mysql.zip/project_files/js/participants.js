function selector(selector) {
    return document.querySelector(selector);
}

// Add new participant
const btnSave = selector('#btnSave');
btnSave.addEventListener('click', (e) => {
    e.preventDefault();

    let data = new FormData();
    data.append('id', selector('#id').value);
    data.append('fullname', selector('#fullname').value);
    data.append('gender', selector('#gender').value);
    data.append('age', selector('#age').value);
    data.append('mobile', selector('#mobile').value);
    data.append('btemp', selector('#btemp').value);
    data.append('diagnosed', selector('#diagnosed').value);
    data.append('encounter', selector('#encounter').value);
    data.append('vaccinated', selector('#vaccinated').value);
    data.append('nationality', selector('#nationality').value);

    if (btnSave.innerHTML === 'Save') {
        saveParticipant(data);
    } else {
        updateParticipantRecord(data);
    }

})


function saveParticipant(data) {
   
    fetch('./php/saveParticipant.php', {
        method: 'POST',
        body: data
    })
        .then(response => response.text())
        .then(() => location.reload())

}


function updateParticipantRecord(data) {
   
    fetch('./php/updateParticipant.php', {
        method: 'POST',
        body: data
    })
        .then(response => response.text())
        .then(() => location.reload())

}


function clearModalForm() {
    selector('#id').value = '';
    selector('#fullname').value = '';
    selector('#gender').value = '';
    selector('#age').value = '';
    selector('#mobile').value = '';
    selector('#btemp').value = '';
    selector('#diagnosed').value = '';
    selector('#encounter').value = '';
    selector('#vaccinated').value = '';
    selector('#nationality').value = '';
    selector('#exampleModalLabel').innerHTML = 'Add new participant';
    btnSave.innerHTML = 'Save';
}


function showModalForm(data = []) {
    selector('#id').value          = data.length == 0 ? '' : data.id;
    selector('#fullname').value    = data.length == 0 ? '' : data.fullname;
    selector('#gender').value      = data.length == 0 ? '' : data.gender;
    selector('#age').value         = data.length == 0 ? '' : data.age;
    selector('#mobile').value      = data.length == 0 ? '' : data.mobile;
    selector('#btemp').value       = data.length == 0 ? '' : data.btemp;
    selector('#diagnosed').value   = data.length == 0 ? '' : data.diagnosed;
    selector('#encounter').value   = data.length == 0 ? '' : data.encounter;
    selector('#vaccinated').value  = data.length == 0 ? '' : data.vaccinated;
    selector('#nationality').value = data.length == 0 ? '' : data.nationality;
    selector('#exampleModalLabel').innerHTML = data.length == 0 ? 'Add new participant' :'Update participant';
    btnSave.innerHTML = data.length == 0 ? 'Save' : 'Update';
}


function updateParticipant(id) {

    fetch(`./php/getParticipant.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
            new bootstrap.Modal(selector('#exampleModal'), {}).show();
            showModalForm(data);
        })

}


function deleteParticipant(id) {

    let response = confirm('Do you want to delete this participant with an ID: ' + id + '?');

    let formID = new FormData();
    formID.append('id', id);

    if (response) {
        fetch('./php/deleteParticipant.php', {
            method: 'POST',
            body: formID,
        })
            .then(response => response.text())
            .then(data => location.reload())
    }

}

// Search participant
function searchParticipant() {
    let keyword = document.querySelector('#keyword').value;

    $.ajax({
        url: './php/getParticipants.php',
        method: 'GET',
        data: { keyword: keyword },
        dataType: 'json',
        success: (response) => {
            $('#participantList').empty();

            $.each(response, (key, value) => {
                const data = {
                    id: value.id,
                    fullname: value.fullname,
                    gender: value.gender,
                    age: value.age,
                    mobile: value.mobile,
                    btemp: value.btemp,
                    diagnosed: value.diagnosed,
                    encounter: value.encounter,
                    vaccinated: value.vaccinated,
                    nationality: value.nationality
                }
                insertItemToTable(data);
            });
        }
    })
}
// End


function getParticipants() {
    
    fetch('./php/getParticipants.php')
        .then((response) => response.json())
        .then((data) => {
            data.forEach(item => {
                insertItemToTable(item)
            });
        });

}


function insertItemToTable(data) {
    let output = `
        <tr>
            <td>${data.fullname}</td>
            <td>${data.gender}</td>
            <td>${data.age}</td>
            <td>${data.mobile}</td>
            <td>${data.btemp}</td>
            <td>${data.diagnosed}</td>
            <td>${data.encounter}</td>
            <td>${data.vaccinated}</td>
            <td>${data.nationality}</td>
            <td>
                <input type="hidden" id="${data.id}" />
                <button type="button" class="btn btn-warning" onclick="updateParticipant(${data.id})">Update</button>
                <button type="button" class="btn btn-danger" onclick="deleteParticipant(${data.id})">Delete</button>
            </td>
        </tr>
    `;

    let participantList = $('#participantList')
    participantList.append(output);
}

function insertItemToDropdown() {
    fetch('./data/countries.json').then(response => response.json())
        .then(data => {
            let dataArray = [];
            $.each(data, (key, value) => {
                if(!dataArray.includes(value.nationality)) {
                    dataArray.push(value.nationality);
                    let output = `<option>${value.nationality}</option>`;
                    $('#nationality').append(output);
                }
            });
        });
}


// During page load
window.addEventListener('load', () => {
    getParticipants();
    insertItemToDropdown();
})