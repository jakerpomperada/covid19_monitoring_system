<!doctype html>
    <html lang="en">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Participants | CRUD APP</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">   
    
            <?php include('common/header.php') ?>

            <br/>
            <div class="container">
                <h1>List of Participants</h1>

                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo" onclick="clearModalForm()">New Participant</button>

                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Name</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Age</th>
                            <th scope="col">Mobile No.</th>
                            <th scope="col">Body Temp.</th>
                            <th scope="col">COVID-19 Diagnosed</th>
                            <th scope="col">COVID-19 Encounter</th>
                            <th scope="col">Vaccinated</th>
                            <th scope="col">Nationality</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody class="table-group-divider" id="participantList"></tbody>
                </table>
            </div>


            <!-- Modal -->           
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Add new participant</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="mb-3">
                                    <label for="fullname" class="col-form-label">Name:</label>
                                    <input type="text" class="form-control" id="fullname" required>
                                </div>
                                <div class="mb-3">
                                    <label for="gender" class="col-form-label">Gender:</label>
                                    <select class="form-select" aria-label="Default select example" id="gender" required>                                
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>                                    
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="age" class="col-form-label">Age:</label>
                                    <input type="number" class="form-control" id="age" required>
                                </div>
                                <div class="mb-3">
                                    <label for="mobile" class="col-form-label">Mobile No.:</label>
                                    <input type="number" class="form-control" id="mobile" required>
                                </div>
                                <div class="mb-3">
                                    <label for="btemp" class="col-form-label">Body Temp:</label>
                                    <input type="number" class="form-control" id="btemp" required>
                                </div>
                                <div class="mb-3">
                                    <label for="diagnosed" class="col-form-label">COVID-19 Diagnosed: (Yes/No)</label>
                                    <select class="form-select" aria-label="Default select example" id="diagnosed" required>                                
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>                                    
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="encounter" class="col-form-label">COVID-19 Encounter: (Yes/No)</label>
                                    <select class="form-select" aria-label="Default select example" id="encounter" required>                                
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>                                    
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="vaccinated" class="col-form-label">Vaccinated: (Yes/No)</label>
                                    <select class="form-select" aria-label="Default select example" id="vaccinated" required>                                
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>                                    
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="nationality" class="col-form-label">Nationality:</label>
                                    <select class="form-select" aria-label="Default select example" id="nationality" required></select>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <input type="hidden" id="id" value="">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                             <button type="button" class="btn btn-primary" id="btnSave">Save</button>
                        </div>
                    </div>
                </div>
            </div>

        <?php include('common/footer.php') ?>

        <script src="js/participants.js"></script> 
    
    </body>
</html>