<?php

    $dbhost = 'localhost';
    $dbusername = 'root';
    $dbpassword = '';
    $dbname = 'crudapp';

    $connection = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);

?>