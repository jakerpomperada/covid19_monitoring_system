<?php

    include 'connection.php';

    if (!$connection) die('Connection failed: ' . mysqli_connect_error());

    $status = array();

    // Diagnosed
    $sql = "SELECT COUNT(id) AS statusCount, diagnosed 
            FROM participants 
            WHERE diagnosed IN ('Yes', 'No')
            GROUP BY diagnosed";
    
    $result = mysqli_query($connection, $sql);

    while ($row = mysqli_fetch_assoc($result)) {
        $status['Diagnosed'][] = [
            'statusCount' => $row['statusCount'],
            'status' => $row['diagnosed']
        ];
    }
    // End Diagnosed


    // Encounter
    $encounter = "SELECT COUNT(id) AS statusCount, encounter 
            FROM participants 
            WHERE encounter IN ('Yes', 'No')
            GROUP BY encounter";
    
    $result = mysqli_query($connection, $encounter);

    while ($row = mysqli_fetch_assoc($result)) {
        $status['Encounter'][] = [
            'statusCount' => $row['statusCount'],
            'status' => $row['encounter']
        ];
    }
    // End Encounter

    // Vaccinated
    $sql = "SELECT COUNT(id) AS statusCount, vaccinated 
            FROM participants 
            WHERE vaccinated IN ('Yes', 'No')
            GROUP BY vaccinated";
    
    $result = mysqli_query($connection, $sql);

    while ($row = mysqli_fetch_assoc($result)) {
        $status['Vaccinated'][] = [
            'statusCount' => $row['statusCount'],
            'status' => $row['vaccinated']
        ];
    }
    mysqli_close($connection);
    // End Vaccinated


    header('Content-type: application/json');
    echo json_encode($status);

?>