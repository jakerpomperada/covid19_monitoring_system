<?php

    include 'connection.php';

    if (!$connection) die('Connection failed: ' . mysqli_connect_error());

    $sql = "SELECT COUNT(id) AS totalEncounter FROM `participants` WHERE `encounter`='Yes'";
    
    $result = mysqli_query($connection, $sql);

    $totalEncounter = mysqli_fetch_assoc($result);

    header('Content-type: application/json');
    echo json_encode($totalEncounter);

    mysqli_close($connection);

?>