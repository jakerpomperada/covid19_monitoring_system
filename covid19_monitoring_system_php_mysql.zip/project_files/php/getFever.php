<?php

    include 'connection.php';

    if (!$connection) die('Connection failed: ' . mysqli_connect_error());

    $sql = "SELECT COUNT(id) AS totalFever FROM `participants` WHERE `btemp` > 36";
    
    $result = mysqli_query($connection, $sql);

    $totalFever = mysqli_fetch_assoc($result);

    header('Content-type: application/json');
    echo json_encode($totalFever);

    mysqli_close($connection);

?>