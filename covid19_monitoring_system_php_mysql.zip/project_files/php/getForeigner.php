<?php

    include 'connection.php';

    if (!$connection) die('Connection failed: ' . mysqli_connect_error());

    $sql = "SELECT COUNT(id) AS totalForeigner FROM `participants` WHERE `nationality` != 'Filipino'";
    
    $result = mysqli_query($connection, $sql);

    $totalForeigner = mysqli_fetch_assoc($result);

    header('Content-type: application/json');
    echo json_encode($totalForeigner);

    mysqli_close($connection);

?>