<?php

    include 'connection.php';

    if (!$connection) die('Connection failed: ' . mysqli_connect_error());

    $sql = "SELECT COUNT(id) AS totalMinor FROM `participants` WHERE `age` < 18";
    
    $result = mysqli_query($connection, $sql);

    $totalMinor = mysqli_fetch_assoc($result);

    header('Content-type: application/json');
    echo json_encode($totalMinor);

    mysqli_close($connection);

?>