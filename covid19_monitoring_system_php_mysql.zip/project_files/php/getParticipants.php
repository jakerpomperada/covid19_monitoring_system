<?php

include 'connection.php';

// Check the connection
if (!$connection) die("Connection failed: " . mysqli_connect_error());

$sql = "SELECT * FROM participants ORDER BY created DESC";

if (isset($_GET['keyword'])) $sql = "SELECT * FROM participants 
                                     WHERE `fullname` LIKE '" . $_GET['keyword'] . "%'
                                     OR `gender` LIKE '" . $_GET['keyword'] . "%'
                                     OR `age` LIKE '" . $_GET['keyword'] . "%'
                                     OR `mobile` LIKE '" . $_GET['keyword'] . "%'
                                     OR `btemp` LIKE '" . $_GET['keyword'] . "%'
                                     OR `diagnosed` LIKE '" . $_GET['keyword'] . "%'
                                     OR `encounter` LIKE '" . $_GET['keyword'] . "%'
                                     OR `vaccinated` LIKE '" . $_GET['keyword'] . "%'
                                     OR `nationality` LIKE '" . $_GET['keyword'] . "%'";

$result = mysqli_query($connection, $sql);

$participants = array();

while ($row = mysqli_fetch_assoc($result)) {
    $participants[] = $row;
}

header('Content-type: application/json');
echo json_encode($participants);

mysqli_close($connection);

?>