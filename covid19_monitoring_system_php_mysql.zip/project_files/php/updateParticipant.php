<?php

    include 'connection.php';

    if (!$connection) die('Connection failed: ' . mysqli_connect_error());

    $fullname    = $_POST['fullname'];
    $gender      = $_POST['gender'];
    $age         = $_POST['age'];
    $mobile      = $_POST['mobile'];
    $btemp       = $_POST['btemp'];
    $diagnosed   = $_POST['diagnosed'];
    $encounter   = $_POST['encounter'];
    $vaccinated  = $_POST['vaccinated'];
    $nationality = $_POST['nationality'];
    
    $sql = "UPDATE participants SET " .
            "fullname = '" . $fullname . "', " .
            "gender = '" . $gender . "', " .
            "age = '" . $age . "', " .
            "mobile = '" . $mobile . "', " .
            "btemp = '" . $btemp . "', " .
            "diagnosed = '" . $diagnosed . "', " .
            "encounter = '" . $encounter . "', " .
            "vaccinated = '" . $vaccinated . "', " .
            "nationality = '" . $nationality . "' " .
            "WHERE id = " . $_POST['id'];

    mysqli_query($connection, $sql);

    echo mysqli_insert_id($connection);

    mysqli_close($connection);

?>